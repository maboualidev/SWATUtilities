clear;clc;close all;
%%

filename = './Data/plant.dat';

%%
plantDB = readSWATPlantDB(filename);