clear;clc;close all;
%%

inFilename = './Data/plant.dat';
outFilename = './Output/plant.dat';

%%
plantDB = readSWATPlantDB(inFilename);

%%
writeSWATPlantDB(plantDB,outFilename);